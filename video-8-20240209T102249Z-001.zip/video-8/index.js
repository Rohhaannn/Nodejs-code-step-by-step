const colors = require("colors");
console.log("package".blue);
console.log("Node Manager".green);
console.log("Node Manager".bgBlue);

/*interview question

Q. what is package.json files
=> it keeps detaila related to our project.
  which details ?
  => related to coding like project version, project name, git repo, comnds used, packages used

Q.  How to make it ?

Q.  How to install external package ?

Q.  what is package-lock.json file
=>  It keeps details of our packages  

Q.  Node.js is single threaded or multithreaded ?
=>  Node.js is single threaded. Completes one task then move to another.

*/
